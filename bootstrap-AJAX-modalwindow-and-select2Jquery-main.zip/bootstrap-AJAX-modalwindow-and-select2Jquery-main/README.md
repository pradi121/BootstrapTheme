# bootstrap-AJAX-modalwindow-and-select2Jquery
This website about, example for ajax calling from remote file, and bootstrap modal window, select2 using jquery, and a form validation.
